def game():
    welcome()
    what_you_need_to_do()
    question()
    correct_or_not()
