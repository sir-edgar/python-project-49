### Hexlet tests and linter status:
[![Actions Status](https://github.com/sir-edgar/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/sir-edgar/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/4a5994db1733f3bd167e/maintainability)](https://codeclimate.com/github/sir-edgar/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/sOPhW9wbu3XkYextvndFqn1Nx.svg)](https://asciinema.org/a/sOPhW9wbu3XkYextvndFqn1Nx)

[![asciicast](https://asciinema.org/a/U6vO1eFAOUyjZpVyNZgUgpUnd.svg)](https://asciinema.org/a/U6vO1eFAOUyjZpVyNZgUgpUnd)
